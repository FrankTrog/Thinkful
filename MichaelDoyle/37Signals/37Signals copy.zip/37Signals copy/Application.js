$(document).ready (function() {
	$("#box1") .on ("mouseenter", function(){
		$("#bannerbc") .css ("text-indent", "0");
	});
	$("#box1") .on ("mouseout", function(){
		$("#bannerbc") .css ("text-indent", "-5000px");
	});
	$("#box1").on('mouseenter', function(){
  		$("#banner").hide();
  	});
	$("#box1").on('mouseout', function(){
  		$("#banner").show();
  	});
	$("#box2") .on ("mouseenter", function(){
		$("#bannerhr") .css ("text-indent", "0");
	});
	$("#box2") .on ("mouseout", function(){
		$("#bannerhr") .css ("text-indent", "-5000px");
	});
	$("#box2").on('mouseenter', function(){
  		$("#banner").hide();
  	});
	$("#box2").on('mouseout', function(){
  		$("#banner").show();
  	});
	$("#box3") .on ("mouseenter", function(){
		$("#bannercf") .css ("text-indent", "0");
	});
	$("#box3") .on ("mouseout", function(){
		$("#bannercf") .css ("text-indent", "-5000px");
	});
	$("#box3").on('mouseenter', function(){
  		$("#banner").hide();
  	});
	$("#box3").on('mouseout', function(){
  		$("#banner").show();
  	});
});